package task3;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;

public class Main {

    public static void main(String[] args) {
        Consumer<String> helloService = n -> System.out.println("Hello " + n + "!");
        helloService.accept("Academy");
    }
}
