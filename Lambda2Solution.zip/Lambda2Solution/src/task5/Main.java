package task5;

import java.util.function.Function;

public class Main {

    public static void main(String[] args) {
        Function<Integer, String> fizzBuzz = n -> {
            if (n % 15 == 0) {
                return "FizzBuzz";
            }
            else if (n % 3 == 0) {
                return "Fizz";
            }
            else if (n % 5 == 0) {
                return "Buzz";
            }
            else {
                return Integer.toString(n);
            }
        };

        for (int i = 0; i < 100; i++) {
            System.out.println(fizzBuzz.apply(i));
        }
    }
}


