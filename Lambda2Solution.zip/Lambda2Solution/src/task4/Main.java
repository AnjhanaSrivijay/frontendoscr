package task4;

import java.util.function.Consumer;

public class Main {

    public static void main(String[] args) {
        Consumer<Integer> fizzBuzz = n -> {
            if (n % 15 == 0) {
                System.out.println("FizzBuzz");
            }
            else if (n % 3 == 0) {
                System.out.println("Fizz");
            }
            else if (n % 5 == 0) {
                System.out.println("Buzz");
            }
            else {
                System.out.println(n);
            }
        };

        for (int i = 0; i < 100; i++) {
            fizzBuzz.accept(i);
        }
    }
}


