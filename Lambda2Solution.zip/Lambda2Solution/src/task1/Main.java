package task1;

import java.util.Random;

public class Main {
    public static void main(String[] args) {

        Calculator plusCalculator = (x, y) -> x + y;
        int result = plusCalculator.calculate(6,2);
        System.out.println(result);

        Calculator minusCalculator = (x, y) -> x - y;
        int result2 = minusCalculator.calculate(6,2);
        System.out.println(result2);

        Calculator multiplyCalculator = (x, y) -> x * y;
        int result3 = multiplyCalculator.calculate(6,2);
        System.out.println(result3);
    }
}
