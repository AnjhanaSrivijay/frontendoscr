package task1;

@FunctionalInterface
public interface Calculator {
    int calculate(int x, int y);
}
