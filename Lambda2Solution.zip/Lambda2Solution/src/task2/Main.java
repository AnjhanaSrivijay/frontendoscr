package task2;

import task1.Calculator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;

public class Main {

    public static void main(String[] args) {

        BiFunction<Integer, Integer, Integer> plusCalculator = (x, y) -> x + y;
        int result = plusCalculator.apply(6,2);
        System.out.println(result);

        BiFunction<Integer, Integer, Integer> minusCalculator = (x, y) -> x - y;
        int result2 = minusCalculator.apply(6,2);
        System.out.println(result2);

        BiFunction<Integer, Integer, Integer> multiplyCalculator = (x, y) -> x * y;
        int result3 = multiplyCalculator.apply(6,2);
        System.out.println(result3);
    }
}
