package com.example.miniproject2team3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Miniproject2team3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
