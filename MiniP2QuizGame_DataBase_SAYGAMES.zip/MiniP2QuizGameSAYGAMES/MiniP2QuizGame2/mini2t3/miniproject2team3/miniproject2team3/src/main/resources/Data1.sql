INSERT INTO QUESTION(prompt, optionA , optionB , optionC , correct_answer )
VALUES ('How many elements are in the periodic table', '118', '117', '116', 1)

INSERT INTO QUESTION(prompt, optionA , optionB , optionC , correct_answer )
VALUES ('How many ghosts chase Pac-Man at the start of each game?', '3', '5', '4', 3)

