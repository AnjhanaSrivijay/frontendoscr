package com.example.demo;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.ArrayList;
import java.util.List;

@Controller
public class MVCController {
    @GetMapping("/task1")
    public String task1() {
        return "task1";
    }

    @GetMapping("/task2")
    public String task2(Model model) {
        model.addAttribute("name", "Academy");
        return "task2";
    }

    @GetMapping("/task3")
    public String task3(Model model, @RequestParam String name) {
        model.addAttribute("name", name);
        return "task3";
    }

    @GetMapping("/task4")
    public String task4(Model model, @RequestParam(required=false, defaultValue = "Academy")
    String name) {
        model.addAttribute("name", name);
        return "task3";
    }

    @GetMapping("/task5/{name1}")
    public String task5(Model model, @PathVariable String name1) {
        model.addAttribute("name", name1);
        return "task3";
    }

    @GetMapping("/task6")
    public String task6(Model model) {
        Book book1 = new Book("The Iliad", 349, "Homer");
        model.addAttribute("book", book1);
        return "task6";
    }

    @GetMapping("/task7")
    public String task7(Model model) {
        List<Book> books1 = new ArrayList();
        books1.add(new Book("The Iliad", 549, "Homer"));
        books1.add(new Book("Another book", 199, "Another author"));
        books1.add(new Book("Yet another book", 549, "Yet another author"));
        model.addAttribute("books", books1);
        return "task7";
    }

    @GetMapping("/task8")
    public String task8(Model model) {
        List<Book> books1 = new ArrayList();
        books1.add(new Book("The Iliad", 549, "Homer"));
        books1.add(new Book("Another book", 199, "Another author"));
        books1.add(new Book("Yet another book", 549, "Yet another author"));
        model.addAttribute("books", books1);
        return "task8";
    }

    @GetMapping("/task9")
    public String task9get() {
        return "task9";
    }

    @PostMapping("/task9")
    public String task9(Model model, @RequestParam String title, @RequestParam int price,
                        @RequestParam String author) {
        Book book1 = new Book(title, price, author);
        model.addAttribute("book", book1);
        return "task9";
    }
}
