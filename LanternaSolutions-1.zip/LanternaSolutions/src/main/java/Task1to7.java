import com.googlecode.lanterna.input.KeyStroke;
import com.googlecode.lanterna.input.KeyType;
import com.googlecode.lanterna.terminal.DefaultTerminalFactory;
import com.googlecode.lanterna.terminal.Terminal;

public class Task1to7 {
    public static void main(String[] args) throws Exception {
        // Task 4
        DefaultTerminalFactory terminalFactory = new DefaultTerminalFactory();
        Terminal terminal = terminalFactory.createTerminal();
        terminal.setCursorVisible(false);

        // Task 5
        terminal.setCursorPosition(1, 1);
        terminal.putCharacter('A');

        terminal.setCursorPosition(2, 2);
        terminal.putCharacter('B');

        terminal.setCursorPosition(3, 3);
        terminal.putCharacter('C');

        terminal.flush();

        // Task 5
        // horizontal
        terminal.setCursorPosition(4, 4);
        for (int column = 4; column < 10; column++) {
            //terminal.setCursorPosition(column, 4);
            terminal.putCharacter('X');
        }

        // vertical
        for (int row = 5; row < 12; row++) {
            terminal.setCursorPosition(5, row); // go to position(column, row)
            terminal.putCharacter('Y');
        }

        // Task 6
        String message = "This is a String printed out in Lanterna by iterating over the characters";
        terminal.setCursorPosition(10, 14);
        for (int i = 0; i < message.length(); i++) {
            terminal.putCharacter(message.charAt(i)); // the cursor automatically moves to the next position so no need to change it´s position explicitly

        }
        terminal.flush();

        // Task 7 (Will only read input once!)
        KeyStroke keyStroke = null;
        do {
            Thread.sleep(5); // might throw InterruptedException
            keyStroke = terminal.pollInput();
        } while (keyStroke == null);

        KeyType type = keyStroke.getKeyType();
        Character c = keyStroke.getCharacter(); // used Character instead of char because it might be null

        System.out.println("keyStroke.getKeyType(): " + type
                + " keyStroke.getCharacter(): " + c);



    }

}
