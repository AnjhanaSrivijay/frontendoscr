# Visual Studio Code

Download and install Visual Studio Code:

https://code.visualstudio.com/

(Just press next, next, next in the installation)

![](01.png)

# Live Server

Open Visual Studio Code, press the extensions-icon (it looks like four boxes) and search for "live server". Press **Install**

![](02.png)